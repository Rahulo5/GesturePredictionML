package com.example.gestureprediction;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class Images extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_images);

        RecyclerView recyclerView = findViewById(R.id.recyclerViewImages);

        ArrayList<Integer> images = new ArrayList<Integer>();

        images.add(R.drawable.frame_10010_r);

        Adapter adapter = new Adapter(getApplicationContext(),images);

        recyclerView.setAdapter(adapter);

        recyclerView.setLayoutManager(new GridLayoutManager(this,3));


    }
}
