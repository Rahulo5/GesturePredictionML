package com.example.gestureprediction;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent i = getIntent();
        Integer res = i.getIntExtra("image",0);

        final ImageView imageView = findViewById(R.id.imageView);

        imageView.setImageResource(res);

        Button selectImage = findViewById(R.id.selectImage);

        selectImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), Images.class);
                startActivity(i);
            }
        });

        Button testImage = findViewById(R.id.testImage);

        testImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bitmap bitmap = BitmapFactory.decodeResource(getResources(),R.drawable.frame_10010_r);

                Bitmap grayScale = toGrayscale(bitmap);

                printImage(grayScale);

                for(int y=0; y<grayScale.getHeight(); y++){
                    for(int x=0; x<grayScale.getWidth(); x++){
                        if(grayScale.getPixel(x,y) > 40){
                            grayScale.setPixel(x, y, 0xffffff);
                        }
                        else{
                            grayScale.setPixel(x, y, 0x000000);
                        }
                    }
                }

                printImage(grayScale);

                imageView.setImageBitmap(grayScale);

            }
        });

    }

    public Bitmap toGrayscale(Bitmap bmpOriginal)
    {
        int width, height;
        height = bmpOriginal.getHeight();
        width = bmpOriginal.getWidth();

        Bitmap bmpGrayscale = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmpGrayscale);
        Paint paint = new Paint();
        ColorMatrix cm = new ColorMatrix();
        cm.setSaturation(0);
        ColorMatrixColorFilter f = new ColorMatrixColorFilter(cm);
        paint.setColorFilter(f);
        c.drawBitmap(bmpOriginal, 0, 0, paint);
        return bmpGrayscale;
    }

    public void printImage(Bitmap b){
        for(int i=0;i<b.getHeight();i++){
            for(int j=0;j<b.getWidth();j++){
                Log.d("PixelPrint",b.getPixel(j,i)+" ");
            }
        }
    }

}
