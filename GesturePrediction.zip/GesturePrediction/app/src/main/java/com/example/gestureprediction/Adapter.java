package com.example.gestureprediction;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Adapter extends RecyclerView.Adapter<Adapter.UserViewHolder> {

    public ArrayList<Integer> images;
    private OnUserClickLstner listner;
    Context context;

    public interface OnUserClickLstner{
        void onUserClick(int position);
    }

    public interface DeleteItem {
        void delete(int position);
    }

    public void setOnUserClickListner(OnUserClickLstner listner){
        this.listner = listner;
    }

    public Adapter(Context context, ArrayList<Integer> images){
        this.context = context;
        this.images = images;
    }

    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup,int i){
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item,viewGroup,false);
        UserViewHolder viewHolder = new UserViewHolder(view,listner,this.images);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull UserViewHolder userViewHolder, int i){
        Integer currentItem = images.get(i);

        userViewHolder.image.setImageResource(currentItem);

    }

    @Override
    public int getItemCount(){
        return  images.size();
    }

    public class UserViewHolder extends RecyclerView.ViewHolder{
        public ImageView image;


        public UserViewHolder(@NonNull View itemView, final OnUserClickLstner listner, final ArrayList<Integer> images){
            super(itemView);
            image = itemView.findViewById(R.id.imageViewInItem);
            image.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(context,MainActivity.class);
                    i.putExtra("image",images.get(getAdapterPosition()));
                    context.startActivity(i);
                }
            });
        }
    }
}